import os
import subprocess
import sys
from dotenv import load_dotenv
from gov_integration_sdk import IBMClient

def install_package(package_path):
    """Install the specified package from a wheel file."""
    try:
        subprocess.run(["pip", "install", package_path,"--quiet"], check=True)
        print("Installation of 'gov_integration_sdk' complete.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred during installation: {e}")
        sys.exit(1) 

def sync_facts_to_governance(file_path):
    """Sync facts to the governance cluster using IBMClient."""
    load_dotenv()
    

    api_key = os.getenv('CP4D_API_KEY')
    CP4D_CONFIGS = {
        'url': os.getenv('CP4D_URL', 'https://default-cluster-url.com'), 
        'username': os.getenv('CP4D_USERNAME', 'default_username'),  
        'password': os.getenv('CP4D_PASSWORD', 'default_password')   
    }

    # Check for conflicting credentials
    if api_key and CP4D_CONFIGS['password'] and CP4D_CONFIGS['password'] != 'default_password':
        print("Error: Both API key and password are provided. Please use only one for authentication.")
        sys.exit(1)  # Exit with an error code

    if api_key:
        CP4D_CONFIGS['api_key'] = api_key
        del CP4D_CONFIGS['password']  
    else:
        if 'password' not in CP4D_CONFIGS or CP4D_CONFIGS['password'] == 'default_password':
            print("Error: No valid API key or password provided.")
            sys.exit(1)


    # Initialize the IBMClient
    try:
        client = IBMClient(
            auth_type='CP4D',
            cloud_pak_for_data_configs=CP4D_CONFIGS
        )
    except Exception as e:
        print(f"Failed to initialize IBMClient: {e}")
        sys.exit(1)

    # Sync facts to governance cluster
    if os.path.exists(file_path):
        try:
            client.assets.sync_facts_to_governance_cluster(file_path=file_path)
            
            print(f"Successfully synced facts from {file_path}.")
        except Exception as e:
            print(f"Failed to sync facts: {e}")
    else:
        print(f"File '{file_path}' does not exist. Please check the path.")

if __name__ == "__main__":
    load_dotenv()
    wheel_file_path = os.getenv('WHEEL_FILE_PATH', 'your_file_path')  # Default path

    # Install the package
    install_package(wheel_file_path)

    # Get the path to the  file from an environment variable
    facts_file_path = os.getenv('FACTS_FILE_PATH', 'your_facts_file_path')  # Default path

    # Sync facts to governance cluster
    sync_facts_to_governance(facts_file_path)

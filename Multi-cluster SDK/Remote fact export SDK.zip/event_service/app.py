import os
import base64
from flask import Flask, request, jsonify
from dotenv import load_dotenv
from persistence import Persistence
from service import EventService

app = Flask(__name__)
load_dotenv()

# Initialize persistence and service layers
persistence = Persistence()
event_service = EventService(persistence)

# Fetch the expected credentials from environment variables
EXPECTED_USERNAME = os.getenv('AUTH_USERNAME')
EXPECTED_PASSWORD = os.getenv('AUTH_PASSWORD')
EXPECTED_API_KEY = os.getenv('AUTH_API_KEY')

def verify_credentials() -> bool:
    """Verify Basic Auth credentials."""
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Basic "):
        return False

    encoded_credentials = auth_header.split(" ")[1]
    try:
        decoded_credentials = base64.b64decode(encoded_credentials).decode("utf-8")
        username, secret = decoded_credentials.split(":", 1)
    except (Exception, ValueError):
        return False

    return username == EXPECTED_USERNAME and (secret == EXPECTED_PASSWORD or secret == EXPECTED_API_KEY)

@app.route('/event', methods=['POST'])
def accept_event():
    """Handle event submission."""
    if not verify_credentials():
        return jsonify({"error": "Unauthorized access. Invalid credentials."}), 401

    event = request.json
    if not event:
        return jsonify({"error": "No JSON payload received"}), 400
        
    status_code, message = event_service.accept_event(event)
    return jsonify({"message": message}), status_code

@app.route('/rollout', methods=['POST'])
def roll_out_files():
    """Handle file rollout."""
    if not verify_credentials():
        return jsonify({"error": "Unauthorized access. Invalid credentials."}), 401

    try:
        status_code, message = event_service.roll_out_files()
        print(f"Roll out files result: Status Code: {status_code}, Message: {message}")
        return jsonify({"message": message}), status_code
    except Exception as e:
        print(f"Exception in roll_out_files: {e}")
        return jsonify({"error": "An unexpected error occurred."}), 500

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0')

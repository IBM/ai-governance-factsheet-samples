import secrets
from typing import Tuple

class Auth:
    def __init__(self, valid_tokens: set = None):
        self.valid_tokens = valid_tokens or set()
        self._generate_default_tokens()

    def _generate_default_tokens(self):
        if not self.valid_tokens:
            self.valid_tokens.add(secrets.token_hex(16))

    def validate_token(self, token: str) -> Tuple[bool, str]:
        if token in self.valid_tokens:
            return True, ""
        return False, "Invalid token"

import os
import json
from datetime import datetime
from typing import Optional, Tuple
import shutil

class Persistence:
    def __init__(self, file_path: str = 'data/events', backup_path: Optional[str] = 'data/events_backup'):
        self.file_path = file_path
        self.backup_path = backup_path
        self.latest_file_path = "data/events.jsonl"
        
        # Ensure the directory exists
        self.ensure_directory_exists(os.path.dirname(self.file_path))

    def ensure_directory_exists(self, directory: str) -> None:
        """Ensure the directory exists; create it if it does not."""
        if directory and not os.path.exists(directory):
            os.makedirs(directory)

    def save_event(self, event: dict) -> Tuple[int, str]:
        """Save an event to the current file."""
        try:
            # Ensure the directory exists before accessing files
            self.ensure_directory_exists(os.path.dirname(self.file_path))
            
            if self.latest_file_path is None:
                # Create a new file with a timestamp
                self.latest_file_path = f'{self.file_path}.jsonl'
            
            # Save the event to the current file
            with open(self.latest_file_path, 'a') as f:
                json.dump(event, f)
                f.write('\n')
            
            print(f"Event saved to {self.latest_file_path}")
            return (200, f"Event saved to {self.latest_file_path}")
        
        except Exception as e:
            print(f"Error: {e}")
            return (500, f"An unexpected error occurred: {e}")

    def backup_and_rollout(self) -> Tuple[int, str]:
        """Backup and rollout the current event file."""
        try:
            if self.latest_file_path is None:
                return (404, "No file to roll out. No backup created.")
            

            if os.stat(self.latest_file_path).st_size == 0:
                return (400, "No backup created because the file is empty.")


            timestamp = datetime.now().strftime('%H-%M-%S_%Y-%m-%d')
            backup_file_path = f'{self.backup_path}_{timestamp}.jsonl'
            
            print(f"Backing up {self.latest_file_path} to {backup_file_path}")
            shutil.copy(self.latest_file_path, backup_file_path)
            
            print(f"Removing the old file: {self.latest_file_path}")
            os.remove(self.latest_file_path)
            open(self.latest_file_path, 'w').close() 

            return (200, "Backup and rollout completed successfully.")
        
        except Exception as e:
            print(f"Error: {e}")
            return (500, f"An unexpected error occurred: {e}")

    def get_file_path(self) -> str:
        """Get the path of the current file."""
        return self.latest_file_path if self.latest_file_path else self.file_path

from persistence import Persistence
from typing import Optional, Tuple

class EventService:
    def __init__(self, persistence: Persistence):
        self.persistence = persistence

    def accept_event(self, event: dict) -> Tuple[int, str]:
        try:
            status_code, message = self.persistence.save_event(event)
            return status_code, message
        except Exception as e:
            return 500, f"An unexpected error occurred: {e}"

    def roll_out_files(self) -> Tuple[int, str]:
        try:
            status_code, message = self.persistence.backup_and_rollout()
            return status_code, message
        except Exception as e:
            return 500, f"An unexpected error occurred: {e}"
